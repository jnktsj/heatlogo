#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Copyright 2013 Junko Tsuji

# Initialization: Empty
